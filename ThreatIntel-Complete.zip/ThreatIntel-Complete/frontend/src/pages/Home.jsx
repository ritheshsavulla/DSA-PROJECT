import { Link } from "react-router-dom";

const STAGES = ["Reconnaissance", "Weaponization", "Delivery", "Exploitation", "Installation", "Command & Control", "Actions on Objectives"];
const FEATURES = [
  ["Threat Detection", "Java KMP pattern matching finds known attack indicators in raw security logs."],
  ["Threat Analysis", "Each log gets a severity and a risk score from 1 (critical) to 4 (low)."],
  ["Kill Chain Mapping", "Indicators are mapped to the furthest stage of the Cyber Kill Chain reached."],
  ["Incident Monitoring", "Track every threat as Active, Investigating or Resolved."],
  ["Risk Assessment", "A min-heap and merge sort rank threats so the most urgent comes first."],
  ["Security Dashboard", "Live totals and a recent threats table for your own account only."],
];

export default function Home({ user }) {
  return (
    <div className="page">
      <section className="hero">
        <h1>Threat Intelligence &amp; Cyber Kill Chain Monitoring</h1>
        <p className="subtitle">Detect. Analyze. Respond.</p>
        <p className="lead">
          An intelligent cybersecurity platform for monitoring threats, analyzing attack stages, and improving
          incident response using the Cyber Kill Chain framework.
        </p>
        <div className="row">
          <Link to={user ? "/dashboard" : "/register"} className="btn">Get Started</Link>
          <Link to={user ? "/dashboard" : "/login"} className="btn btn-outline">{user ? "Open Dashboard" : "Login"}</Link>
        </div>
      </section>

      <section>
        <h2>The seven Cyber Kill Chain stages</h2>
        <ol className="chain">
          {STAGES.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ol>
      </section>

      <section>
        <h2>Key Features</h2>
        <div className="grid">
          {FEATURES.map(([t, d]) => (
            <div className="card" key={t}>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
