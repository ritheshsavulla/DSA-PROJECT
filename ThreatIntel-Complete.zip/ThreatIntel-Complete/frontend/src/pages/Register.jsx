import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Register() {
  const navigate = useNavigate();
  const [f, setF] = useState({ full_name: "", email: "", username: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  function validate() {
    if (!f.full_name.trim() || !f.email.trim() || !f.username.trim() || !f.password || !f.confirm) return "All fields are required.";
    if (!EMAIL_RE.test(f.email)) return "Enter a valid email address.";
    if (f.username.trim().length < 3) return "Username must be at least 3 characters.";
    if (f.password.length < 8) return "Password must be at least 8 characters.";
    if (f.password !== f.confirm) return "Passwords do not match.";
    return "";
  }

  async function submit(e) {
    e.preventDefault();
    const v = validate();
    if (v) return setError(v);
    setError("");
    setBusy(true);
    try {
      await api("/api/auth/register", {
        method: "POST",
        auth: false,
        body: { full_name: f.full_name.trim(), email: f.email.trim(), username: f.username.trim(), password: f.password },
      });
      setOk(true);
      setTimeout(() => navigate("/login"), 1500);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-wrap">
      <form className="card auth" onSubmit={submit} noValidate>
        <h2>Create account</h2>
        {ok && <div className="alert ok">Registration successful. Redirecting to login...</div>}
        {error && <div className="alert err">{error}</div>}
        <label>Full Name<input value={f.full_name} onChange={set("full_name")} autoComplete="name" /></label>
        <label>Email<input type="email" value={f.email} onChange={set("email")} autoComplete="email" /></label>
        <label>Username<input value={f.username} onChange={set("username")} autoComplete="username" /></label>
        <label>Password<input type="password" value={f.password} onChange={set("password")} autoComplete="new-password" /></label>
        <label>Confirm Password<input type="password" value={f.confirm} onChange={set("confirm")} autoComplete="new-password" /></label>
        <button className="btn" disabled={busy || ok}>{busy ? "Registering..." : "Register"}</button>
        <p className="muted">Already registered? <Link to="/login">Login</Link></p>
      </form>
    </div>
  );
}
