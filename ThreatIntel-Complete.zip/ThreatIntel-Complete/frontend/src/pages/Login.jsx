import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api, saveSession } from "../api.js";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(location.state?.message || "");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (!identifier.trim() || !password) return setError("Enter your email or username and your password.");
    setError("");
    setBusy(true);
    try {
      const data = await api("/api/auth/login", { method: "POST", auth: false, body: { identifier: identifier.trim(), password } });
      saveSession(data.access_token, data.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-wrap">
      <form className="card auth" onSubmit={submit} noValidate>
        <h2>Login</h2>
        {error && <div className="alert err">{error}</div>}
        <label>Email or Username<input value={identifier} onChange={(e) => setIdentifier(e.target.value)} autoComplete="username" /></label>
        <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
        <button className="btn" disabled={busy}>{busy ? "Logging in..." : "Login"}</button>
        <p className="muted">No account? <Link to="/register">Register</Link></p>
      </form>
    </div>
  );
}
