import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";

const STAGES = ["Reconnaissance", "Weaponization", "Delivery", "Exploitation", "Installation", "Command & Control", "Actions on Objectives"];

export default function Dashboard({ user }) {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [threats, setThreats] = useState([]);
  const [error, setError] = useState("");
  const [updated, setUpdated] = useState(null);

  const load = useCallback(async () => {
    try {
      const [s, t] = await Promise.all([api("/api/threats/stats"), api("/api/threats")]);
      setStats(s);
      setThreats(t);
      setError("");
      setUpdated(new Date());
    } catch (err) {
      if (err.status === 401) navigate("/login", { state: { message: err.message } });
      else setError(err.message);
    }
  }, [navigate]);

  useEffect(() => {
    load();
    const timer = setInterval(load, 5000); // picks up threats saved from the Java GUI
    return () => clearInterval(timer);
  }, [load]);

  async function setStatus(id, status) {
    try {
      await api(`/api/threats/${id}/status`, { method: "PUT", body: { status } });
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function remove(id) {
    if (!window.confirm("Delete this threat?")) return;
    try {
      await api(`/api/threats/${id}`, { method: "DELETE" });
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  const stageCount = (name) => threats.filter((t) => t.kill_chain_stage === name && t.status !== "Resolved").length;
  const cards = [
    ["Total Threats", stats?.total, ""],
    ["Active Threats", stats?.active, "orange"],
    ["Critical Threats", stats?.critical, "red"],
    ["Resolved Threats", stats?.resolved, "green"],
  ];

  return (
    <div className="page">
      <div className="dash-head">
        <div>
          <h1>Threat Intelligence Dashboard</h1>
          <p className="muted">Signed in as {user.full_name} ({user.username}). Auto-refreshes every 5 seconds{updated ? `, last at ${updated.toLocaleTimeString()}` : ""}.</p>
        </div>
        <button className="btn btn-outline" onClick={load}>Refresh</button>
      </div>

      {error && <div className="alert err">{error}</div>}

      <div className="stats">
        {cards.map(([label, value, tone]) => (
          <div className={`card stat ${tone}`} key={label}>
            <span className="stat-label">{label}</span>
            <span className="stat-value">{value ?? "-"}</span>
          </div>
        ))}
      </div>

      <h2>Open threats by kill chain stage</h2>
      <ol className="chain small">
        {STAGES.map((s) => (
          <li key={s} className={stageCount(s) ? "hot" : ""}>{s}<b>{stageCount(s)}</b></li>
        ))}
      </ol>

      <h2>Recent Threats</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Threat</th><th>Detected Patterns</th><th>Kill Chain Stage</th><th>Severity</th>
              <th>Risk Score</th><th>Status</th><th>Date</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {threats.length === 0 && (
              <tr><td colSpan="8" className="empty">
                No threats yet. Open the Java DSA GUI, log in with this account, analyze a log and click SAVE TO DASHBOARD.
              </td></tr>
            )}
            {threats.map((t) => (
              <tr key={t.id}>
                <td className="threat-text" title={t.raw_text}>{t.raw_text.length > 70 ? t.raw_text.slice(0, 67) + "..." : t.raw_text}</td>
                <td>{t.detected_patterns.length ? t.detected_patterns.map((p) => <span className="chip" key={p}>{p}</span>) : <span className="muted">none</span>}</td>
                <td>{t.kill_chain_stage}</td>
                <td><span className={`badge sev-${t.severity.toLowerCase()}`}>{t.severity}</span></td>
                <td className="num">{t.risk_score}</td>
                <td><span className={`badge st-${t.status.toLowerCase()}`}>{t.status}</span></td>
                <td className="nowrap">{new Date(t.created_at + "Z").toLocaleString()}</td>
                <td className="nowrap">
                  {t.status !== "Investigating" && t.status !== "Resolved" && <button className="btn btn-sm btn-outline" onClick={() => setStatus(t.id, "Investigating")}>Investigate</button>}
                  {t.status !== "Resolved" && <button className="btn btn-sm" onClick={() => setStatus(t.id, "Resolved")}>Resolve</button>}
                  <button className="btn btn-sm btn-danger" onClick={() => remove(t.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
