import { NavLink, useNavigate } from "react-router-dom";
import { clearSession } from "../api.js";

export default function Navbar({ user }) {
  const navigate = useNavigate();

  function logout() {
    clearSession();
    navigate("/login");
  }

  return (
    <header className="navbar">
      <NavLink to="/" className="brand">ThreatIntel <span>Kill Chain Monitor</span></NavLink>
      <nav>
        <NavLink to="/" end>Home</NavLink>
        {user ? (
          <>
            <NavLink to="/dashboard">Dashboard</NavLink>
            <button className="btn btn-danger btn-sm" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <NavLink to="/login">Login</NavLink>
            <NavLink to="/register">Register</NavLink>
          </>
        )}
      </nav>
    </header>
  );
}
