from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field, field_validator

STATUSES = ["Active", "Investigating", "Resolved"]


class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    username: str = Field(min_length=3, max_length=60)
    password: str = Field(min_length=8, max_length=72)


class LoginIn(BaseModel):
    identifier: str = Field(min_length=1)
    password: str = Field(min_length=1)


class UserOut(BaseModel):
    id: int
    full_name: str
    email: str
    username: str
    model_config = {"from_attributes": True}


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ThreatIn(BaseModel):
    raw_text: str
    detected_patterns: List[str] = []
    severity: Optional[str] = None
    risk_score: Optional[int] = None
    kill_chain_stage: Optional[str] = None
    status: str = "Active"

    @field_validator("raw_text")
    @classmethod
    def not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError("Threat text cannot be empty")
        return v.strip()

    @field_validator("status")
    @classmethod
    def valid_status(cls, v):
        if v not in STATUSES:
            raise ValueError("Status must be one of: " + ", ".join(STATUSES))
        return v


class StatusIn(BaseModel):
    status: str

    @field_validator("status")
    @classmethod
    def valid_status(cls, v):
        if v not in STATUSES:
            raise ValueError("Status must be one of: " + ", ".join(STATUSES))
        return v


class ThreatOut(BaseModel):
    id: int
    raw_text: str
    detected_patterns: List[str]
    severity: str
    risk_score: int
    kill_chain_stage: str
    status: str
    created_at: datetime


class StatsOut(BaseModel):
    total: int
    active: int
    critical: int
    resolved: int
