from sqlalchemy.orm import Session
from ..models import Threat, User
from ..schemas import ThreatIn
from .analysis_service import analyze_text, SEVERITY_BY_SCORE

ACTIVE_STATUSES = ("Active", "Investigating")


def to_out(t: Threat) -> dict:
    return {
        "id": t.id, "raw_text": t.raw_text,
        "detected_patterns": [p for p in (t.detected_patterns or "").split(",") if p],
        "severity": t.severity, "risk_score": t.risk_score,
        "kill_chain_stage": t.kill_chain_stage, "status": t.status,
        "created_at": t.created_at,
    }


def create_threat(db: Session, user: User, data: ThreatIn) -> Threat:
    patterns, severity, score, stage = analyze_text(data.raw_text)
    if data.detected_patterns:
        patterns = [p.strip().lower() for p in data.detected_patterns if p.strip()]
    if data.risk_score is not None:
        if data.risk_score not in SEVERITY_BY_SCORE:
            raise ValueError("risk_score must be 1 (CRITICAL) to 4 (LOW)")
        score = data.risk_score
        severity = SEVERITY_BY_SCORE[score]
    if data.severity:
        if data.severity.upper() not in SEVERITY_BY_SCORE.values():
            raise ValueError("severity must be CRITICAL, HIGH, MEDIUM or LOW")
        severity = data.severity.upper()
    if data.kill_chain_stage:
        stage = data.kill_chain_stage
    threat = Threat(user_id=user.id, raw_text=data.raw_text, detected_patterns=",".join(patterns),
                    severity=severity, risk_score=score, kill_chain_stage=stage, status=data.status)
    db.add(threat)
    db.commit()
    db.refresh(threat)
    return threat


def list_threats(db: Session, user: User):
    return db.query(Threat).filter(Threat.user_id == user.id).order_by(Threat.created_at.desc(), Threat.id.desc()).all()


def get_threat(db: Session, user: User, threat_id: int):
    return db.query(Threat).filter(Threat.id == threat_id, Threat.user_id == user.id).first()


def compute_stats(db: Session, user: User) -> dict:
    mine = db.query(Threat).filter(Threat.user_id == user.id)
    return {
        "total": mine.count(),
        "active": mine.filter(Threat.status.in_(ACTIVE_STATUSES)).count(),
        "critical": mine.filter(Threat.severity == "CRITICAL").count(),
        "resolved": mine.filter(Threat.status == "Resolved").count(),
    }
