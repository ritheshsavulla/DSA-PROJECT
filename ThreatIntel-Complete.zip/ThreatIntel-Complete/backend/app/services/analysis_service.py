"""Server-side fallback analysis.
The Java GUI performs the real DSA analysis (KMP, etc.) and sends its result.
If a client sends a threat WITHOUT severity / score / stage, this simple
keyword analysis fills the gaps so the database never holds empty values."""

KEYWORDS = {
    # keyword: (risk score, kill chain stage index)
    "ransomware": (1, 4),
    "exfiltration": (1, 6),
    "malware": (2, 4),
    "exploit": (2, 3),
    "c2": (2, 5),
    "suspicious": (3, 0),
    "phishing": (3, 2),
    "port scanning": (4, 0),
}
STAGES = ["Reconnaissance", "Weaponization", "Delivery", "Exploitation",
          "Installation", "Command & Control", "Actions on Objectives"]
SEVERITY_BY_SCORE = {1: "CRITICAL", 2: "HIGH", 3: "MEDIUM", 4: "LOW"}


def analyze_text(text: str):
    lower = text.lower()
    found = [k for k in KEYWORDS if k in lower]
    if not found:
        return [], "LOW", 4, STAGES[0]
    score = min(KEYWORDS[k][0] for k in found)
    stage = max(KEYWORDS[k][1] for k in found)
    return found, SEVERITY_BY_SCORE[score], score, STAGES[stage]
