from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..schemas import StatsOut, StatusIn, ThreatIn, ThreatOut
from ..security import get_current_user
from ..services import threat_service as svc

router = APIRouter(prefix="/api/threats", tags=["threats"])


@router.post("", response_model=ThreatOut, status_code=201)
def add_threat(data: ThreatIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        return svc.to_out(svc.create_threat(db, user, data))
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.get("", response_model=List[ThreatOut])
def get_threats(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return [svc.to_out(t) for t in svc.list_threats(db, user)]


# NOTE: /stats must be declared before /{threat_id}
@router.get("/stats", response_model=StatsOut)
def get_stats(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return svc.compute_stats(db, user)


@router.get("/{threat_id}", response_model=ThreatOut)
def get_one(threat_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = svc.get_threat(db, user, threat_id)
    if t is None:
        raise HTTPException(404, "Threat not found.")
    return svc.to_out(t)


@router.put("/{threat_id}/status", response_model=ThreatOut)
def set_status(threat_id: int, body: StatusIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = svc.get_threat(db, user, threat_id)
    if t is None:
        raise HTTPException(404, "Threat not found.")
    t.status = body.status
    db.commit()
    db.refresh(t)
    return svc.to_out(t)


@router.delete("/{threat_id}")
def delete_threat(threat_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = svc.get_threat(db, user, threat_id)
    if t is None:
        raise HTTPException(404, "Threat not found.")
    db.delete(t)
    db.commit()
    return {"message": "Threat deleted"}
