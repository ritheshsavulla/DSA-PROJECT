from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .database import Base, engine
from .routes import auth, threats

Base.metadata.create_all(bind=engine)  # creates threatintel.db on first run

app = FastAPI(title="Threat Intelligence & Cyber Kill Chain API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET", "POST", "DELETE", "PUT", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    # Turn Pydantic's error list into one readable sentence in "detail"
    parts = []
    for err in exc.errors():
        field = str(err["loc"][-1]) if err.get("loc") else "input"
        msg = str(err.get("msg", "invalid")).replace("Value error, ", "")
        parts.append(f"{field}: {msg}")
    return JSONResponse(status_code=422, content={"detail": "; ".join(parts)})


app.include_router(auth.router)
app.include_router(threats.router)


@app.get("/", tags=["health"])
def health():
    return {"status": "ok", "docs": "/docs"}
