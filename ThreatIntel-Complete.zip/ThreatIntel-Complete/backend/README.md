# Backend (FastAPI + SQLite)

    python -m venv venv
    .\venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    python seed_demo.py          # optional demo account
    python -m uvicorn app.main:app --reload

Swagger: http://127.0.0.1:8000/docs  | Database file: backend/threatintel.db (auto-created)
