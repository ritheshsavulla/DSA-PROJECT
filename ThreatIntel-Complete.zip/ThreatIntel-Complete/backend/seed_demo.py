"""Creates a demo account: demo@example.com / demo / Demo@12345  (run once: python seed_demo.py)"""
from app.database import Base, engine, SessionLocal
from app.models import User
from app.security import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()
if db.query(User).filter(User.username == "demo").first():
    print("Demo user already exists.")
else:
    db.add(User(full_name="Demo Student", email="demo@example.com", username="demo",
                password_hash=hash_password("Demo@12345")))
    db.commit()
    print("Created demo user -> username: demo | email: demo@example.com | password: Demo@12345")
