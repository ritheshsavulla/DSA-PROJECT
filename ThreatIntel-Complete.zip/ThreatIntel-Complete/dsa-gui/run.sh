#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out
javac -d out src/threatintel/*.java && java -cp out threatintel.Main
