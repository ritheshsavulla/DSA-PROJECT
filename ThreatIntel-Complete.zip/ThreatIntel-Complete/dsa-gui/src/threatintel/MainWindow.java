package threatintel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class MainWindow extends JFrame {
    // ---- patterns searched by KMP, with severity score (1=CRITICAL..4=LOW) and kill chain stage index ----
    static final String[] PATTERNS = {"phishing", "malware", "ransomware", "suspicious", "exfiltration", "port scanning", "exploit", "c2"};
    static final int[] SCORE       = {3,          2,         1,            3,            1,              4,               2,         2};
    static final int[] STAGE       = {2,          4,         4,            0,            6,              0,               3,         5};
    static final String[] SEV = {"", "CRITICAL", "HIGH", "MEDIUM", "LOW"};
    static final String SAMPLE = "Suspicious ransomware detected during phishing campaign with malware and data exfiltration";

    static final Color BG = new Color(0x0b1220), PANEL = new Color(0x121c33), INK = new Color(0xe5edf7),
            CYAN = new Color(0x22d3ee), DARK = new Color(0x04121a), RED = new Color(0xdc2626), MUTED = new Color(0x8ea3c0);
    static final Font MONO = new Font(Font.MONOSPACED, Font.PLAIN, 13);

    private final ApiClient api = new ApiClient();
    private final KillChainGraph graph = new KillChainGraph();
    private final PriorityQueue pq = new PriorityQueue();
    private final List<Threat> analyzed = new ArrayList<>();
    private Threat current;
    private int seq = 0;
    private String kmpText = "", analysisText = "", graphText = "";

    private final JTextArea input = area(true);
    private final JTextArea kmpArea = area(false), analysisArea = area(false), graphArea = area(false),
            queueArea = area(false), sortArea = area(false);
    private final JLabel sevLabel = label("Severity: -", 16), scoreLabel = label("Risk Score: -", 16),
            stageLabel = label("ACTIVE STAGE: -", 20), status = label("Ready. Enter a threat and click ANALYZE THREAT.", 13),
            loginStatus = label("Not logged in", 12);
    private final JTextField userField = new JTextField(14);
    private final JPasswordField passField = new JPasswordField(14);

    public MainWindow() {
        super("Threat Intelligence & DSA Analysis Engine");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1280, 800);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));

        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(BG);
        header.setBorder(new EmptyBorder(12, 16, 0, 16));
        header.add(label("Threat Intelligence & DSA Analysis Engine", 24));
        JLabel sub = label("Cyber Kill Chain Monitoring System", 14);
        sub.setForeground(CYAN);
        header.add(sub);
        add(header, BorderLayout.NORTH);

        add(buildLeft(), BorderLayout.WEST);
        add(buildTabs(), BorderLayout.CENTER);

        status.setBorder(new EmptyBorder(4, 16, 8, 16));
        add(status, BorderLayout.SOUTH);
        kmpArea.setText("Run ANALYZE THREAT to see KMP results.");
        analysisArea.setText("Run ANALYZE THREAT to see severity, risk score and kill chain stage.");
        graphArea.setText("Run ANALYZE THREAT to see BFS and DFS over the Cyber Kill Chain graph.");
        renderQueue("");
        renderSort();
    }

    // ------------------------------------------------------------------ UI building
    private JPanel buildLeft() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(8, 16, 8, 6));
        p.setPreferredSize(new Dimension(440, 0));

        p.add(left(label("ENTER THREAT / SECURITY LOG", 13, CYAN)));
        input.setRows(7);
        input.setLineWrap(true);
        input.setWrapStyleWord(true);
        JScrollPane sp = new JScrollPane(input);
        sp.setAlignmentX(LEFT_ALIGNMENT);
        sp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));
        p.add(sp);
        p.add(Box.createVerticalStrut(8));

        JPanel b = new JPanel(new GridLayout(2, 2, 8, 8));
        b.setBackground(BG);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.add(btn("ANALYZE THREAT", CYAN, DARK, e -> analyzeClicked()));
        b.add(btn("RUN COMPLETE DSA ANALYSIS", CYAN, DARK, e -> completeClicked()));
        b.add(btn("LOAD SAMPLE", new Color(0xfacc15), DARK, e -> input.setText(SAMPLE)));
        b.add(btn("CLEAR", RED, Color.WHITE, e -> clearClicked()));
        p.add(b);
        p.add(Box.createVerticalStrut(12));

        JPanel s = new JPanel(new GridLayout(4, 1, 0, 2));
        s.setBackground(PANEL);
        s.setBorder(new EmptyBorder(10, 12, 10, 12));
        s.setAlignmentX(LEFT_ALIGNMENT);
        s.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        s.add(label("ANALYSIS RESULT", 12, CYAN));
        s.add(sevLabel);
        s.add(scoreLabel);
        s.add(stageLabel);
        stageLabel.setForeground(new Color(0xfb923c));
        p.add(s);
        p.add(Box.createVerticalStrut(12));

        JPanel l = new JPanel(new GridBagLayout());
        l.setBackground(PANEL);
        l.setBorder(new EmptyBorder(10, 12, 10, 12));
        l.setAlignmentX(LEFT_ALIGNMENT);
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(3, 3, 3, 3);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        l.add(label("BACKEND LOGIN (same account as the React app)", 12, CYAN), c);
        c.gridwidth = 1; c.gridy = 1; l.add(label("Username/email", 12), c);
        c.gridx = 1; l.add(userField, c);
        c.gridx = 0; c.gridy = 2; l.add(label("Password", 12), c);
        c.gridx = 1; l.add(passField, c);
        c.gridx = 0; c.gridy = 3; c.gridwidth = 2;
        JPanel row = new JPanel(new GridLayout(1, 2, 8, 0));
        row.setOpaque(false);
        row.add(btn("LOGIN", CYAN, DARK, e -> loginClicked()));
        row.add(btn("SAVE TO DASHBOARD", new Color(0x22c55e), DARK, e -> saveClicked()));
        l.add(row, c);
        c.gridy = 4; l.add(loginStatus, c);
        passField.addActionListener(e -> loginClicked());
        p.add(l);
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JTabbedPane buildTabs() {
        JTabbedPane t = new JTabbedPane();
        t.setBorder(new EmptyBorder(8, 0, 0, 16));
        t.addTab("KMP + LPS", new JScrollPane(kmpArea));
        t.addTab("Severity & Stage", new JScrollPane(analysisArea));
        t.addTab("BFS / DFS", new JScrollPane(graphArea));

        JPanel q = new JPanel(new BorderLayout(0, 6));
        q.setBackground(BG);
        JPanel qb = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        qb.setBackground(BG);
        qb.add(btn("ADD TO QUEUE", CYAN, DARK, e -> addToQueue()));
        qb.add(btn("EXTRACT HIGHEST", new Color(0xfb923c), DARK, e -> extractFromQueue()));
        qb.add(btn("PEEK", new Color(0xfacc15), DARK, e -> peekQueue()));
        q.add(qb, BorderLayout.NORTH);
        q.add(new JScrollPane(queueArea), BorderLayout.CENTER);
        t.addTab("Priority Queue (Min Heap)", q);

        JPanel m = new JPanel(new BorderLayout(0, 6));
        m.setBackground(BG);
        JPanel mb = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        mb.setBackground(BG);
        mb.add(btn("SORT ANALYZED THREATS", CYAN, DARK, e -> { renderSort(); say("Merge sort executed on " + analyzed.size() + " analyzed threat(s)."); }));
        m.add(mb, BorderLayout.NORTH);
        m.add(new JScrollPane(sortArea), BorderLayout.CENTER);
        t.addTab("Merge Sort", m);
        return t;
    }

    // ------------------------------------------------------------------ actions
    private void analyzeClicked() {
        String text = input.getText().trim();
        if (text.isEmpty()) { say("Enter a threat or security log first (or click LOAD SAMPLE)."); return; }
        analyze(text);
        say("Analysis complete: " + current.severity + " / " + current.stage + ". Analyzed records: " + analyzed.size());
    }

    private void completeClicked() {
        String text = input.getText().trim();
        if (text.isEmpty()) { say("Enter a threat or security log first (or click LOAD SAMPLE)."); return; }
        if (current == null || !current.text.equals(text)) analyze(text);   // reuse analysis if text unchanged
        else renderAll();
        renderSort();
        say("Complete DSA analysis finished (KMP, LPS, BFS, DFS, Heap, Merge Sort). Use the tabs to inspect each.");
    }

    private void clearClicked() {
        input.setText("");
        current = null;
        sevLabel.setText("Severity: -"); scoreLabel.setText("Risk Score: -"); stageLabel.setText("ACTIVE STAGE: -");
        kmpArea.setText("Run ANALYZE THREAT to see KMP results.");
        analysisArea.setText("Run ANALYZE THREAT to see severity, risk score and kill chain stage.");
        graphArea.setText("Run ANALYZE THREAT to see BFS and DFS over the Cyber Kill Chain graph.");
        say("Input cleared. Analyzed list and queue are kept; they only reset when you close the app.");
    }

    private void analyze(String text) {
        Threat t = new Threat(text, ++seq);
        int best = 4, stageIdx = 0;
        boolean any = false;
        StringBuilder k = new StringBuilder();
        k.append("ALGORITHMS 1 & 2: KMP PATTERN MATCHING + LPS ARRAY CONSTRUCTION\n");
        k.append("==============================================================\n");
        k.append("INPUT  : text of ").append(text.length()).append(" characters, ").append(PATTERNS.length).append(" patterns (case-insensitive)\n");
        k.append("         \"").append(text).append("\"\n\n");
        k.append(String.format("%-18s %-14s %s%n", "Detected Pattern", "Position(s)", "Severity score"));
        k.append("--------------------------------------------------\n");
        StringBuilder missing = new StringBuilder();
        for (int i = 0; i < PATTERNS.length; i++) {
            List<Integer> pos = KMP.search(text, PATTERNS[i]);
            if (pos.isEmpty()) { missing.append(missing.length() > 0 ? ", " : "").append(PATTERNS[i]); continue; }
            any = true;
            t.patterns.add(PATTERNS[i]);
            best = Math.min(best, SCORE[i]);
            stageIdx = Math.max(stageIdx, STAGE[i]);
            k.append(String.format("%-18s %-14s %d (%s)%n", PATTERNS[i], pos.toString(), SCORE[i], SEV[SCORE[i]]));
        }
        if (!any) k.append("(no known pattern found)\n");
        k.append("\nNot found: ").append(missing.length() == 0 ? "-" : missing).append("\n\n");
        k.append("LPS ARRAYS (failure function: longest proper prefix that is also a suffix)\n");
        k.append("--------------------------------------------------------------------------\n");
        for (String p : PATTERNS) {
            k.append(String.format("%-16s %s%n", p, java.util.Arrays.toString(KMP.buildLPS(p)).replace(" ", "")));
        }
        k.append("\nOUTPUT : ").append(t.patterns.size()).append(" pattern(s) detected: ").append(t.patterns).append("\n");
        k.append("TIME   : O(n + m) per pattern  (LPS build O(m), search O(n))\n");
        k.append("SPACE  : O(m)  (the LPS array; matches are extra output)\n");
        kmpText = k.toString();

        t.riskScore = any ? best : 4;
        t.severity = SEV[t.riskScore];
        t.stage = KillChainGraph.STAGES[any ? stageIdx : 0];
        current = t;
        analyzed.add(t);
        buildAnalysisText(t, any);
        buildGraphText(t);
        renderAll();
    }

    private void buildAnalysisText(Threat t, boolean any) {
        StringBuilder a = new StringBuilder();
        a.append("THREAT ANALYSIS (derived from KMP results)\n==========================================\n");
        a.append("INPUT    : detected patterns ").append(t.patterns).append("\n\n");
        a.append(String.format("%-16s %-10s %-6s %s%n", "Pattern", "Severity", "Score", "Kill chain stage"));
        for (int i = 0; i < PATTERNS.length; i++) {
            boolean hit = t.patterns.contains(PATTERNS[i]);
            a.append(String.format("%s %-14s %-10s %-6d %s%n", hit ? "*" : " ", PATTERNS[i], SEV[SCORE[i]], SCORE[i], KillChainGraph.STAGES[STAGE[i]]));
        }
        a.append("\n(* = found in this threat)\n\n");
        a.append("RULE     : lowest score wins (1 = CRITICAL ... 4 = LOW); furthest stage in the attack wins.\n");
        a.append("OUTPUT   : Severity = ").append(t.severity).append(", Risk Score = ").append(t.riskScore).append("\n");
        a.append("           ACTIVE STAGE = ").append(t.stage).append("\n");
        if (!any) a.append("NOTE     : no known pattern, so defaults LOW / 4 / Reconnaissance were used.\n");
        a.append("TIME     : O(p) for p patterns found     SPACE: O(1)\n");
        analysisText = a.toString();
    }

    private void buildGraphText(Threat t) {
        int[] parent = new int[KillChainGraph.STAGES.length];
        List<Integer> bfs = graph.bfs(0, parent), dfs = graph.dfs(0);
        int target = KillChainGraph.indexOf(t.stage);
        StringBuilder g = new StringBuilder();
        g.append("ALGORITHMS 3 & 4: BFS and DFS ON THE CYBER KILL CHAIN GRAPH\n");
        g.append("===========================================================\n");
        g.append("INPUT  : directed graph, 7 nodes, adjacency list, start = Reconnaissance\n\n");
        g.append("ADJACENCY LIST\n").append(graph.adjacencyText()).append("\n");
        g.append("BFS (queue, level by level)\n  ").append(path(bfs)).append("\n");
        g.append("  Time: O(V + E)   Space: O(V)\n\n");
        g.append("DFS (recursion, deepest path first, then backtrack)\n  ").append(path(dfs)).append("\n");
        g.append("  Time: O(V + E)   Space: O(V)\n\n");
        g.append("WHY THEY DIFFER: BFS visits every neighbour of a node before going deeper;\n");
        g.append("DFS follows one branch to the end (Actions on Objectives) before backtracking.\n\n");
        g.append("ATTACK PATH TO ACTIVE STAGE (shortest path using BFS parent links)\n  ")
         .append(path(graph.shortestPath(0, target))).append("\n");
        g.append("ACTIVE STAGE: ").append(t.stage).append("\n");
        graphText = g.toString();
    }

    private static String path(List<Integer> nodes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < nodes.size(); i++) sb.append(i > 0 ? "\n  -> " : "").append(KillChainGraph.STAGES[nodes.get(i)]);
        return sb.toString();
    }

    private void renderAll() {
        kmpArea.setText(kmpText); analysisArea.setText(analysisText); graphArea.setText(graphText);
        kmpArea.setCaretPosition(0); analysisArea.setCaretPosition(0); graphArea.setCaretPosition(0);
        sevLabel.setText("Severity: " + current.severity);
        scoreLabel.setText("Risk Score: " + current.riskScore);
        stageLabel.setText("ACTIVE STAGE: " + current.stage);
        sevLabel.setForeground(current.riskScore == 1 ? new Color(0xf87171) : current.riskScore == 2 ? new Color(0xfb923c)
                : current.riskScore == 3 ? new Color(0xfacc15) : new Color(0x4ade80));
    }

    // ------------------------------------------------------------------ priority queue
    private void addToQueue() {
        if (current == null) { say("Analyze a threat first, then add it to the queue."); return; }
        if (current.inQueue) { say("This analyzed threat is already in the queue. Analyze again to add another record."); return; }
        pq.insert(current);
        current.inQueue = true;
        renderQueue("INSERTED: " + current + "\n");
        say("Inserted into min heap. Queue size: " + pq.size());
    }

    private void peekQueue() {
        Threat t = pq.peek();
        if (t == null) { renderQueue("PEEK: queue is empty.\n"); return; }
        renderQueue("PEEK (not removed)\n  Threat: " + t.text + "\n  Severity: " + t.severity + "\n  Risk Score: " + t.riskScore + "\n");
    }

    private void extractFromQueue() {
        Threat t = pq.extractMin();
        if (t == null) { renderQueue("EXTRACT: queue is empty. Add threats first.\n"); return; }
        t.inQueue = false;
        renderQueue("EXTRACTED THREAT\n  Threat: " + t.text + "\n  Severity: " + t.severity + "\n  Risk Score: " + t.riskScore + "\n");
        say("Extracted highest priority threat. Remaining: " + pq.size());
    }

    private void renderQueue(String op) {
        StringBuilder s = new StringBuilder();
        s.append("ALGORITHM 5: MIN HEAP / PRIORITY QUEUE (manual array heap)\n");
        s.append("==========================================================\n");
        s.append("INPUT  : analyzed threat (text, severity, risk score). Priority 1 = highest ... 4 = lowest\n\n");
        s.append(op.isEmpty() ? "(use ADD TO QUEUE, PEEK or EXTRACT HIGHEST)\n" : op).append("\n");
        s.append("REMAINING QUEUE (").append(pq.size()).append(") - internal heap array order, index 0 = highest priority\n");
        Threat[] snap = pq.snapshot();
        if (snap.length == 0) s.append("  (empty)\n");
        for (int i = 0; i < snap.length; i++) s.append("  [").append(i).append("] ").append(snap[i]).append("\n");
        s.append("\nTIME   : Insert O(log n)   Extract O(log n)   Peek O(1)\n");
        s.append("SPACE  : O(n)\n");
        queueArea.setText(s.toString());
        queueArea.setCaretPosition(0);
    }

    // ------------------------------------------------------------------ merge sort
    private void renderSort() {
        Threat[] before = analyzed.toArray(new Threat[0]);
        Threat[] after = MergeSort.sort(before);
        StringBuilder s = new StringBuilder();
        s.append("ALGORITHM 6: MERGE SORT / ANALYZED THREATS\n==========================================\n");
        s.append("INPUT  : ").append(before.length).append(" analyzed threat(s) in analysis order\n");
        for (int i = 0; i < before.length; i++) s.append("  ").append(i + 1).append(". ").append(before[i]).append("\n");
        s.append("\nOUTPUT : sorted by risk score ascending (most urgent first, stable for ties)\n");
        if (after.length == 0) s.append("  (nothing analyzed yet)\n");
        for (int i = 0; i < after.length; i++) s.append("  ").append(i + 1).append(". ").append(after[i]).append("\n");
        s.append("\nTIME   : O(n log n)\nSPACE  : O(n)\n");
        s.append("\nEach ANALYZE click makes one record, so analyzing the same text twice gives two records.\n");
        sortArea.setText(s.toString());
        sortArea.setCaretPosition(0);
    }

    // ------------------------------------------------------------------ backend calls
    private void loginClicked() {
        String u = userField.getText().trim(), p = new String(passField.getPassword());
        if (u.isEmpty() || p.isEmpty()) { loginStatus.setText("Enter username/email and password."); return; }
        loginStatus.setText("Logging in...");
        new SwingWorker<String, Void>() {
            @Override protected String doInBackground() {
                try { api.login(u, p); return null; } catch (ApiClient.ApiException e) { return e.getMessage(); }
            }
            @Override protected void done() {
                try {
                    String err = get();
                    loginStatus.setText(err == null ? "Logged in as " + api.getUsername() : "Login failed: " + err);
                    loginStatus.setForeground(err == null ? new Color(0x4ade80) : new Color(0xf87171));
                    if (err == null) say("Logged in. You can now SAVE TO DASHBOARD.");
                } catch (Exception e) { loginStatus.setText("Login failed: " + e.getMessage()); }
            }
        }.execute();
    }

    private void saveClicked() {
        if (current == null) { say("Analyze a threat before saving it."); return; }
        if (!api.isLoggedIn()) { say("Log in first (left panel) so the threat is saved to your account."); loginStatus.setText("Please log in first."); return; }
        if (current.saved) { say("This analysis is already saved. Analyze again to save another record."); return; }
        final Threat t = current;
        say("Saving to backend...");
        new SwingWorker<String, Void>() {
            String err;
            @Override protected String doInBackground() {
                try { return api.saveThreat(t); } catch (ApiClient.ApiException e) { err = e.getMessage(); return null; }
            }
            @Override protected void done() {
                try {
                    String id = get();
                    if (id != null) { t.saved = true; say("Saved to dashboard (threat id " + id + "). Open the React dashboard to see it."); }
                    else { say("Save failed: " + err); if (!api.isLoggedIn()) loginStatus.setText("Session expired. Please log in again."); }
                } catch (Exception e) { say("Save failed: " + e.getMessage()); }
            }
        }.execute();
    }

    // ------------------------------------------------------------------ helpers
    private void say(String m) { status.setText(m); }

    private static JTextArea area(boolean editable) {
        JTextArea a = new JTextArea();
        a.setFont(MONO); a.setBackground(PANEL); a.setForeground(INK); a.setCaretColor(CYAN);
        a.setEditable(editable); a.setBorder(new EmptyBorder(8, 10, 8, 10));
        return a;
    }

    private static JLabel label(String t, int size) { return label(t, size, INK); }

    private static JLabel label(String t, int size, Color c) {
        JLabel l = new JLabel(t);
        l.setForeground(c);
        l.setFont(new Font(Font.SANS_SERIF, Font.BOLD, size));
        return l;
    }

    private static JComponent left(JComponent c) { c.setAlignmentX(LEFT_ALIGNMENT); return c; }

    private static JButton btn(String text, Color bg, Color fg, ActionListener a) {
        JButton b = new JButton(text);
        b.setBackground(bg); b.setForeground(fg);
        b.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        b.setOpaque(true); b.setContentAreaFilled(true); b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(9, 12, 9, 12));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(a);
        return b;
    }
}
