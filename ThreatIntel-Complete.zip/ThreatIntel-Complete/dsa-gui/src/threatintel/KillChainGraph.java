package threatintel;

import java.util.ArrayList;
import java.util.List;

/** Cyber Kill Chain as a directed graph with a hand-made adjacency list. */
public class KillChainGraph {
    public static final String[] STAGES = {
        "Reconnaissance", "Weaponization", "Delivery", "Exploitation",
        "Installation", "Command & Control", "Actions on Objectives"
    };

    private final List<List<Integer>> adj = new ArrayList<>();

    public KillChainGraph() {
        for (int i = 0; i < STAGES.length; i++) adj.add(new ArrayList<>());
        edge(0, 1); edge(0, 2);   // recon -> build weapon, or straight to delivery (e.g. phishing)
        edge(1, 3);               // weaponized exploit can go directly to exploitation
        edge(2, 3); edge(2, 4);   // delivery -> exploit, or install directly
        edge(3, 4); edge(3, 5);   // exploitation -> install, or straight to C2
        edge(4, 5);
        edge(5, 6);
    }

    private void edge(int from, int to) { adj.get(from).add(to); }

    public static int indexOf(String stage) {
        for (int i = 0; i < STAGES.length; i++) if (STAGES[i].equals(stage)) return i;
        return 0;
    }

    public String adjacencyText() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < STAGES.length; i++) {
            sb.append(String.format("%-22s ->", STAGES[i]));
            if (adj.get(i).isEmpty()) sb.append(" (end)");
            for (int v : adj.get(i)) sb.append(" ").append(STAGES[v]).append(";");
            sb.append("\n");
        }
        return sb.toString();
    }

    /** BFS with a manual array queue. Visits level by level. O(V + E), space O(V). */
    public List<Integer> bfs(int start, int[] parentOut) {
        int n = STAGES.length;
        boolean[] seen = new boolean[n];
        int[] queue = new int[n];
        int head = 0, tail = 0;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < n; i++) parentOut[i] = -1;
        seen[start] = true;
        queue[tail++] = start;
        while (head < tail) {
            int u = queue[head++];
            order.add(u);
            for (int v : adj.get(u)) {
                if (!seen[v]) { seen[v] = true; parentOut[v] = u; queue[tail++] = v; }
            }
        }
        return order;
    }

    /** DFS (recursive). Goes as deep as possible before backtracking. O(V + E), space O(V). */
    public List<Integer> dfs(int start) {
        List<Integer> order = new ArrayList<>();
        dfsVisit(start, new boolean[STAGES.length], order);
        return order;
    }

    private void dfsVisit(int u, boolean[] seen, List<Integer> order) {
        seen[u] = true;
        order.add(u);
        for (int v : adj.get(u)) if (!seen[v]) dfsVisit(v, seen, order);
    }

    /** Shortest attack path start -> target, rebuilt from BFS parent links. */
    public List<Integer> shortestPath(int start, int target) {
        int[] parent = new int[STAGES.length];
        bfs(start, parent);
        List<Integer> path = new ArrayList<>();
        for (int v = target; v != -1; v = parent[v]) path.add(0, v);
        return path;
    }
}
