package threatintel;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Talks to FastAPI only. The GUI never touches SQLite. */
public class ApiClient {
    public static final String BASE = "http://127.0.0.1:8000";
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private String token;
    private String username;

    public static class ApiException extends Exception {
        public ApiException(String m) { super(m); }
    }

    public boolean isLoggedIn() { return token != null; }
    public String getUsername() { return username; }

    public void login(String identifier, String password) throws ApiException {
        String body = "{\"identifier\":" + q(identifier) + ",\"password\":" + q(password) + "}";
        String res = send("/api/auth/login", body, false);
        token = field(res, "access_token");
        username = field(res, "username");
        if (token == null) throw new ApiException("Unexpected login response from server.");
    }

    /** Returns the new threat id. */
    public String saveThreat(Threat t) throws ApiException {
        StringBuilder p = new StringBuilder("[");
        for (int i = 0; i < t.patterns.size(); i++) p.append(i > 0 ? "," : "").append(q(t.patterns.get(i)));
        p.append("]");
        String body = "{\"raw_text\":" + q(t.text) + ",\"detected_patterns\":" + p
                + ",\"severity\":" + q(t.severity) + ",\"risk_score\":" + t.riskScore
                + ",\"kill_chain_stage\":" + q(t.stage) + ",\"status\":\"Active\"}";
        String res = send("/api/threats", body, true);
        int i = res.indexOf("\"id\":");
        if (i < 0) return "?";
        int s = i + 5, e = s;
        while (e < res.length() && Character.isDigit(res.charAt(e))) e++;
        return res.substring(s, e);
    }

    private String send(String path, String json, boolean auth) throws ApiException {
        if (auth && token == null) throw new ApiException("Please log in first.");
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(BASE + path))
                .timeout(Duration.ofSeconds(8)).header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json));
        if (auth) b.header("Authorization", "Bearer " + token);
        try {
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 200 && r.statusCode() < 300) return r.body();
            String detail = field(r.body(), "detail");
            if (r.statusCode() == 401 && auth) token = null;   // expired/invalid: force re-login
            throw new ApiException(detail != null ? detail : "Server error " + r.statusCode());
        } catch (IOException e) {
            throw new ApiException("Cannot connect to backend at " + BASE + ". Is uvicorn running?");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException("Request interrupted.");
        }
    }

    private static String q(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default: if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    /** Tiny JSON helper: first string value for "key". */
    static String field(String json, String key) {
        int k = json.indexOf("\"" + key + "\"");
        if (k < 0) return null;
        int c = json.indexOf(':', k);
        int s = c + 1;
        while (s < json.length() && json.charAt(s) == ' ') s++;
        if (s >= json.length() || json.charAt(s) != '"') return null;
        StringBuilder sb = new StringBuilder();
        for (int i = s + 1; i < json.length(); i++) {
            char ch = json.charAt(i);
            if (ch == '\\' && i + 1 < json.length()) { sb.append(json.charAt(++i)); }
            else if (ch == '"') break;
            else sb.append(ch);
        }
        return sb.toString();
    }
}
