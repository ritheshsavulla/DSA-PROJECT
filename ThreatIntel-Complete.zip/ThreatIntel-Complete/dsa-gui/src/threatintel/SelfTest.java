package threatintel;

import java.util.List;

/** Console check of every algorithm: java -cp out threatintel.Main --selftest */
public class SelfTest {
    static int failures = 0;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + name); if (!ok) failures++; }

    static Threat mk(String t, int score, int seq) { Threat x = new Threat(t, seq); x.riskScore = score; return x; }

    public static void run() {
        check("LPS of 'abab'", java.util.Arrays.toString(KMP.buildLPS("abab")).equals("[0, 0, 1, 2]"));
        check("LPS of 'aabaaab'", java.util.Arrays.toString(KMP.buildLPS("aabaaab")).equals("[0, 1, 0, 1, 2, 2, 3]"));
        String s = "Suspicious ransomware detected during phishing campaign with malware and data exfiltration";
        check("KMP finds ransomware at 11", KMP.search(s, "ransomware").equals(List.of(11)));
        check("KMP is case-insensitive (suspicious at 0)", KMP.search(s, "suspicious").equals(List.of(0)));
        check("KMP overlapping matches", KMP.search("aaaa", "aa").equals(List.of(0, 1, 2)));
        check("KMP no match", KMP.search(s, "port scanning").isEmpty());

        KillChainGraph g = new KillChainGraph();
        List<Integer> bfs = g.bfs(0, new int[7]), dfs = g.dfs(0);
        check("BFS order " + bfs, bfs.toString().equals("[0, 1, 2, 3, 4, 5, 6]"));
        check("DFS order " + dfs, dfs.toString().equals("[0, 1, 3, 4, 5, 6, 2]"));
        check("BFS and DFS differ", !bfs.equals(dfs));
        check("Shortest path to stage 6 " + g.shortestPath(0, 6), g.shortestPath(0, 6).toString().equals("[0, 1, 3, 5, 6]"));

        PriorityQueue pq = new PriorityQueue();
        int[] scores = {3, 1, 4, 2, 1, 3, 2, 4, 1, 3};
        for (int i = 0; i < scores.length; i++) pq.insert(mk("t" + i, scores[i], i));
        check("Peek returns lowest score, oldest first (t1)", pq.peek().text.equals("t1"));
        StringBuilder out = new StringBuilder();
        while (pq.size() > 0) out.append(pq.extractMin().riskScore);
        check("Heap extracts in sorted order " + out, out.toString().equals("1112233344"));
        check("Extract on empty is null", pq.extractMin() == null);

        Threat[] arr = {mk("a", 3, 0), mk("b", 1, 1), mk("c", 4, 2), mk("d", 2, 3), mk("e", 1, 4)};
        Threat[] sorted = MergeSort.sort(arr);
        StringBuilder o2 = new StringBuilder();
        for (Threat t : sorted) o2.append(t.text);
        check("Merge sort stable ascending: " + o2, o2.toString().equals("bedac"));
        System.out.println(failures == 0 ? "\nALL TESTS PASSED" : "\n" + failures + " TEST(S) FAILED");
        if (failures > 0) System.exit(1);
    }
}
