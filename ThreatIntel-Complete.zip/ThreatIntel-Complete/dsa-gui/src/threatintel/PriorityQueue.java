package threatintel;

/** Manual MIN HEAP. Lowest riskScore (1 = CRITICAL) is extracted first. Ties: older threat first. */
public class PriorityQueue {
    private Threat[] heap = new Threat[8];
    private int size = 0;

    public int size() { return size; }

    private boolean less(Threat a, Threat b) {
        return a.riskScore < b.riskScore || (a.riskScore == b.riskScore && a.seq < b.seq);
    }

    private void swap(int i, int j) { Threat t = heap[i]; heap[i] = heap[j]; heap[j] = t; }

    /** O(log n) */
    public void insert(Threat t) {
        if (size == heap.length) {           // grow array by hand
            Threat[] bigger = new Threat[size * 2];
            for (int i = 0; i < size; i++) bigger[i] = heap[i];
            heap = bigger;
        }
        heap[size] = t;
        int i = size++;
        while (i > 0 && less(heap[i], heap[(i - 1) / 2])) {   // sift up
            swap(i, (i - 1) / 2);
            i = (i - 1) / 2;
        }
    }

    /** O(1) */
    public Threat peek() { return size == 0 ? null : heap[0]; }

    /** O(log n) */
    public Threat extractMin() {
        if (size == 0) return null;
        Threat top = heap[0];
        heap[0] = heap[--size];
        heap[size] = null;
        int i = 0;
        while (true) {                                         // sift down
            int l = 2 * i + 1, r = l + 1, s = i;
            if (l < size && less(heap[l], heap[s])) s = l;
            if (r < size && less(heap[r], heap[s])) s = r;
            if (s == i) break;
            swap(i, s);
            i = s;
        }
        return top;
    }

    /** Heap array in index order (this is the real internal layout). */
    public Threat[] snapshot() {
        Threat[] copy = new Threat[size];
        for (int i = 0; i < size; i++) copy[i] = heap[i];
        return copy;
    }
}
