package threatintel;

/** Manual stable merge sort by riskScore ascending. No Arrays.sort / Collections.sort. */
public class MergeSort {

    public static Threat[] sort(Threat[] input) {
        Threat[] a = new Threat[input.length];
        for (int i = 0; i < input.length; i++) a[i] = input[i];
        if (a.length > 1) mergeSort(a, new Threat[a.length], 0, a.length - 1);
        return a;
    }

    private static void mergeSort(Threat[] a, Threat[] tmp, int lo, int hi) {
        if (lo >= hi) return;
        int mid = (lo + hi) / 2;
        mergeSort(a, tmp, lo, mid);
        mergeSort(a, tmp, mid + 1, hi);
        int i = lo, j = mid + 1, k = lo;
        while (i <= mid && j <= hi) tmp[k++] = (a[i].riskScore <= a[j].riskScore) ? a[i++] : a[j++];
        while (i <= mid) tmp[k++] = a[i++];
        while (j <= hi) tmp[k++] = a[j++];
        for (k = lo; k <= hi; k++) a[k] = tmp[k];
    }
}
