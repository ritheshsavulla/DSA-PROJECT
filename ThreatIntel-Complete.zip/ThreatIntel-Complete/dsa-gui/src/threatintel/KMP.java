package threatintel;

import java.util.ArrayList;
import java.util.List;

/** Manual KMP. No indexOf(), no regex. Case-insensitive. */
public class KMP {

    private static char lower(char c) {
        return (c >= 'A' && c <= 'Z') ? (char) (c + 32) : c;
    }

    /** LPS[i] = length of the longest proper prefix of p[0..i] that is also a suffix. O(m). */
    public static int[] buildLPS(String p) {
        int m = p.length();
        int[] lps = new int[m];
        int len = 0, i = 1;
        while (i < m) {
            if (lower(p.charAt(i)) == lower(p.charAt(len))) {
                lps[i++] = ++len;
            } else if (len > 0) {
                len = lps[len - 1];          // fall back, do not advance i
            } else {
                lps[i++] = 0;
            }
        }
        return lps;
    }

    /** Returns every start index (0-based) where pattern occurs in text. O(n + m). */
    public static List<Integer> search(String text, String pattern) {
        List<Integer> positions = new ArrayList<>();
        int n = text.length(), m = pattern.length();
        if (m == 0 || n < m) return positions;
        int[] lps = buildLPS(pattern);
        int i = 0, j = 0;
        while (i < n) {
            if (lower(text.charAt(i)) == lower(pattern.charAt(j))) {
                i++; j++;
                if (j == m) {
                    positions.add(i - m);
                    j = lps[j - 1];
                }
            } else if (j > 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
        return positions;
    }
}
