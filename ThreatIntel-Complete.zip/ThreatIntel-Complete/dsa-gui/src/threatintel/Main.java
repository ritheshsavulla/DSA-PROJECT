package threatintel;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--selftest")) { SelfTest.run(); return; }
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
