package threatintel;

import java.util.ArrayList;
import java.util.List;

/** One analysed threat record. */
public class Threat {
    public final String text;
    public final List<String> patterns = new ArrayList<>();
    public String severity = "LOW";
    public int riskScore = 4;
    public String stage = "Reconnaissance";
    public int seq;              // insertion order, used as heap tie-breaker
    public boolean saved;        // already sent to the dashboard
    public boolean inQueue;      // already in the priority queue

    public Threat(String text, int seq) { this.text = text; this.seq = seq; }

    public String shortText() { return text.length() > 60 ? text.substring(0, 57) + "..." : text; }

    @Override public String toString() { return shortText() + " | " + severity + " | " + riskScore; }
}
