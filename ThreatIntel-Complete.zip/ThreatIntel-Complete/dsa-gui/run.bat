@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -d out src\threatintel\*.java
if errorlevel 1 (echo Compile failed. Check that JDK 17+ is installed: javac -version & pause & exit /b 1)
java -cp out threatintel.Main
