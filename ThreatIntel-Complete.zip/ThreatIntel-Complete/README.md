# Threat Intelligence & Cyber Kill Chain Monitoring System

## 1. Overview
Security logs are analysed by hand-written Java DSA algorithms (KMP, BFS, DFS, min heap, merge sort). The result is saved
through a REST API into SQLite and shown on a React SOC-style dashboard. Every threat belongs to the user who saved it.

## 2. Architecture
    React (Vite)  --HTTP/JSON-->  FastAPI  -->  SQLite
    Java Swing GUI --HTTP/JSON--> FastAPI  -->  SQLite
Only FastAPI touches the database. React and Java share one JWT login.

## 3. Technologies
React 18, Vite, React Router, plain CSS | Python, FastAPI, Uvicorn, SQLAlchemy, SQLite, Pydantic, PyJWT, bcrypt | Java 17+, Swing, java.net.http.HttpClient

## 4. Folder structure
    ThreatIntel-Complete/
    ├── backend/   app/{main,database,models,schemas,security}.py, routes/{auth,threats}.py,
    │              services/{threat_service,analysis_service}.py, seed_demo.py, requirements.txt
    ├── frontend/  index.html, package.json, src/{App,api,main}.jsx, components/, pages/, styles.css
    └── dsa-gui/   run.bat, run.sh, src/threatintel/{Main,MainWindow,ApiClient,KMP,KillChainGraph,
                   PriorityQueue,MergeSort,Threat,SelfTest}.java

## 5-8. Setup and run (three terminals, in this order)
**Backend**

    cd backend
    python -m venv venv
    .\venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    python seed_demo.py
    python -m uvicorn app.main:app --reload
Swagger: http://127.0.0.1:8000/docs. The file `backend/threatintel.db` is created on first start.

**Frontend**

    cd frontend
    npm install
    npm run dev
Open http://localhost:5173

**Java GUI** (JDK 17+; check with `javac -version`)

    cd dsa-gui
    .\run.bat
or `javac -d out src\threatintel\*.java; java -cp out threatintel.Main`. Console self-test of all algorithms: `java -cp out threatintel.Main --selftest`.

## 9. API endpoints
| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /api/auth/register | no | create user (password stored as bcrypt hash) |
| POST | /api/auth/login | no | body `{identifier, password}` returns JWT + user |
| GET | /api/auth/me | JWT | current user |
| POST | /api/threats | JWT | save a threat for the logged-in user |
| GET | /api/threats | JWT | list own threats |
| GET | /api/threats/stats | JWT | total / active / critical / resolved, computed with SQL counts |
| GET | /api/threats/{id} | JWT | one own threat |
| PUT | /api/threats/{id}/status | JWT | Active, Investigating or Resolved |
| DELETE | /api/threats/{id} | JWT | delete own threat |

## 10-11. DSA algorithms and complexity (all in Java, no library equivalents)
| Algorithm | File | Use in project | Time | Space |
|---|---|---|---|---|
| LPS array | KMP.java | failure table for each pattern | O(m) | O(m) |
| KMP search | KMP.java | find indicators in the log, case-insensitive | O(n+m) | O(m) |
| BFS | KillChainGraph.java | level-order traversal, shortest attack path to the active stage | O(V+E) | O(V) |
| DFS | KillChainGraph.java | deepest-path-first traversal | O(V+E) | O(V) |
| Min heap | PriorityQueue.java | most urgent threat first (score 1 = highest) | insert O(log n), extract O(log n), peek O(1) | O(n) |
| Merge sort | MergeSort.java | order analysed threats by risk score | O(n log n) | O(n) |

Rules: score CRITICAL=1, HIGH=2, MEDIUM=3, LOW=4 (lowest score among detected patterns wins).
ransomware, exfiltration = 1; malware, exploit, c2 = 2; suspicious, phishing = 3; port scanning = 4.
Stage of each pattern: port scanning, suspicious = Reconnaissance; phishing = Delivery; exploit = Exploitation;
malware, ransomware = Installation; c2 = Command & Control; exfiltration = Actions on Objectives. The furthest stage wins.

## 12. Database
`users(id, full_name, email UNIQUE, username UNIQUE, password_hash, created_at)`
`threats(id, user_id FK -> users.id, raw_text, detected_patterns, severity, risk_score, kill_chain_stage, status, created_at)`
One user has many threats. Every threat query filters by the user id taken from the JWT.

## 13. Demonstration flow
1. Register on the React site (or run `python seed_demo.py`: user `demo`, password `Demo@12345`) and log in. The dashboard shows zeros.
2. Open the Java GUI, log in with the same account.
3. Click LOAD SAMPLE, then RUN COMPLETE DSA ANALYSIS. Visit each tab: KMP + LPS, Severity & Stage, BFS / DFS.
4. Priority Queue tab: ADD TO QUEUE, PEEK, EXTRACT HIGHEST. Analyze other logs and add them to see the heap reorder.
5. Merge Sort tab: SORT ANALYZED THREATS.
6. Click SAVE TO DASHBOARD. Within 5 seconds the threat and updated counts appear on the React dashboard.
7. Register a second user: their dashboard is empty, proving per-user data.
8. Logout clears the token; /dashboard redirects to /login.
